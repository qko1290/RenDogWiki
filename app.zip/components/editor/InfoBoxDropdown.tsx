'use client';

import React, { useState } from 'react';
import { useSlate } from 'slate-react';
import { Editor, Range, Transforms } from 'slate';
import type { InfoBoxType } from '@/types/slate';
import insertInfoBox from './helpers/insertInfoBox';

type InfoBoxDropdownProps = {
  selectionRef: React.RefObject<Range | null>;
};

const InfoBoxDropdown = ({ selectionRef }: InfoBoxDropdownProps) => {
  const editor = useSlate();
  const [open, setOpen] = useState(false);

  const handleSelect = (type: InfoBoxType) => {
    if (selectionRef.current) {
      Transforms.select(editor, selectionRef.current);
    }
    insertInfoBox(editor, type);
    setOpen(false);
  };

  return (
    <div style={{ position: 'relative' }}>
      <button
        type="button"
        onMouseDown={(e) => {
          e.preventDefault();
          setOpen(prev => !prev);
        }}
        style={{
          padding: '6px 10px',
          borderRadius: '4px',
          border: '1px solid #ccc',
          cursor: 'pointer',
        }}
      >
        📦 박스 삽입 ▾
      </button>
      {open && (
        <ul style={dropdownStyle}>
          <li style={liStyle} onMouseDown={() => handleSelect('info')}>ℹ️ 정보</li>
          <li style={liStyle} onMouseDown={() => handleSelect('warning')}>⚠️ 주의</li>
          <li style={liStyle} onMouseDown={() => handleSelect('danger')}>🚫 경고</li>
        </ul>
      )}
    </div>
  );
};

export default InfoBoxDropdown;

const dropdownStyle: React.CSSProperties = {
  position: 'absolute',
  top: '100%',
  left: 0,
  margin: 0,
  padding: '4px 0',
  background: 'white',
  border: '1px solid #ccc',
  borderRadius: '4px',
  listStyle: 'none',
  boxShadow: '0 2px 6px rgba(0,0,0,0.15)',
  zIndex: 100,
};

const liStyle: React.CSSProperties = {
  padding: '6px 12px',
  cursor: 'pointer',
  whiteSpace: 'nowrap',
  fontSize: '14px',
  userSelect: 'none',
};
