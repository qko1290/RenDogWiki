'use client';

import React from 'react';
import { RenderElementProps } from 'slate-react';
import { Node } from 'slate';
import { getHeadingId } from './helpers/getHeadingId';
import type {
  CustomElement,
  LinkElement,
  LinkBlockElement,
  InfoBoxElement,
  HeadingOneElement,
  HeadingTwoElement,
  HeadingThreeElement,
  ParagraphElement
} from '@/types/slate';

type ElementProps = RenderElementProps & {
  editor: any;
  onIconClick: (element: CustomElement) => void;
};

const Element = ({ attributes, children, element, editor, onIconClick }: ElementProps) => {
  switch (element.type) {
    case 'link': {
      const el = element as LinkElement;
      return (
        <a {...attributes} href={el.url} style={{ color: 'blue', textDecoration: 'none' }}>
          {children}
        </a>
      );
    }

    case 'link-block': {
      const el = element as LinkBlockElement;
      return (
        <div
          {...attributes}
          contentEditable={false}
          style={{
            display: 'flex',
            alignItems: 'center',
            padding: '12px',
            border: '1px solid #ddd',
            borderRadius: '6px',
            marginBottom: '8px',
          }}
        >
          {el.favicon && (
            <img src={el.favicon} alt="favicon" style={{ width: 24, height: 24, marginRight: 8 }} />
          )}
          <a href={el.url} target="_blank" rel="noopener noreferrer" style={{ color: '#0070f3', textDecoration: 'none', flexGrow: 1 }}>
            {el.sitename || el.url}
          </a>
        </div>
      );
    }

    case 'heading-one':
    case 'heading-two':
    case 'heading-three': {
      const el = element as HeadingOneElement | HeadingTwoElement | HeadingThreeElement;
      const level = el.type === 'heading-one' ? 1 : el.type === 'heading-two' ? 2 : 3;
      const fontSize = level === 1 ? '28px' : level === 2 ? '22px' : '18px';
      const Tag = (`h${level}` as 'h1' | 'h2' | 'h3');

      return (
        <Tag {...attributes} id={getHeadingId(el)} style={{ fontSize }}>
          <span onClick={() => onIconClick(el)} contentEditable={false} style={{ cursor: 'pointer', marginRight: '0.3em' }}>
            {el.icon?.startsWith('http') ? (
              <img src={el.icon} alt="icon" style={{ width: '1em', verticalAlign: 'middle' }} />
            ) : (
              el.icon || (level === 1 ? '📌' : level === 2 ? '🔖' : '📝')
            )}
          </span>
          {children}
        </Tag>
      );
    }

    case 'divider':
      return <hr {...attributes} />;

    case 'paragraph': {
      const el = element as ParagraphElement;
      return (
        <p {...attributes} style={{ textAlign: el.textAlign || 'left' }}>
          {children}
        </p>
      );
    }

    case 'info-box': {
      const el = element as InfoBoxElement;
      const colors = {
        info: '#e8f4fd',
        warning: '#fff9e6',
        danger: '#fdecea',
      };
      const icons = {
        info: 'ℹ️',
        warning: '⚠️',
        danger: '🚫',
      };

      return (
        <div
          {...attributes}
          style={{
            background: colors[el.boxType],
            padding: '10px',
            borderRadius: '6px',
            border: '1px solid #ccc',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
          }}
        >
          <span contentEditable={false}>{icons[el.boxType]}</span>
          <div style={{ flex: 1 }}>{children}</div>
        </div>
      );
    }

    default:
      return <p {...attributes}>{children}</p>;
  }
};

export default Element;
