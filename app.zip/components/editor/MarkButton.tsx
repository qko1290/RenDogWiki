'use client';

import React from 'react';
import { useSlate } from 'slate-react';
import { Editor } from 'slate';
import type { MarkFormat } from '@/types/slate';
import { isMarkActive, toggleMark } from './helpers/toggleMark';

type MarkButtonProps = {
  format: MarkFormat;
  label: string;
};

const MarkButton = ({ format, label }: MarkButtonProps) => {
  const editor = useSlate();
  const active = isMarkActive(editor, format);

  return (
    <button
      onMouseDown={(e) => {
        e.preventDefault();
        toggleMark(editor, format);
      }}
      style={{
        fontWeight: active ? 'bold' : 'normal',
        background: active ? '#eee' : '#fff',
        border: '1px solid #ccc',
        borderRadius: '4px',
        padding: '4px 8px',
        cursor: 'pointer',
      }}
    >
      {label}
    </button>
  );
};

export default MarkButton;
