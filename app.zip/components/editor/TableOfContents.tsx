'use client';

import React from 'react';

type Heading = {
  text: string;
  id: string;
  level: 1 | 2 | 3;
  icon: string;
};

type Props = {
  headings: Heading[];
};

const TableOfContents = ({ headings }: Props) => {
  return (
    <div style={{ position: 'fixed', right: '20px', top: '100px', width: '200px' }}>
      <h3>📚 목차</h3>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {headings.map((heading) => (
          <li
            key={heading.id}
            style={{ marginLeft: `${(heading.level - 1) * 20}px`, marginBottom: '8px' }}
          >
            <button
              onClick={(e) => {
                e.preventDefault();
                const el = document.getElementById(heading.id);
                if (el) {
                  el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
              }}
              style={{
                background: 'none',
                border: 'none',
                padding: 0,
                textAlign: 'left',
                cursor: 'pointer',
                fontSize: '14px',
              }}
            >
              {heading.icon} {heading.text}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TableOfContents;
