'use client';

import React, { useState } from 'react';

type DropdownButtonProps = {
  label: string;
  items: string[];
  onSelect: (value: string) => void;
};

const DropdownButton = ({ label, items, onSelect }: DropdownButtonProps) => {
  const [open, setOpen] = useState(false);

  return (
    <div style={{ position: 'relative' }}>
      <button
        onMouseDown={(e) => {
          e.preventDefault();
          setOpen(prev => !prev);
        }}
        style={{
          padding: '6px 10px',
          borderRadius: '4px',
          border: '1px solid #ccc',
          cursor: 'pointer',
        }}
      >
        {label} ▾
      </button>

      {open && (
        <ul style={dropdownStyle}>
          {items.map((item, idx) => (
            <li
              key={idx}
              style={liStyle}
              onMouseDown={() => {
                onSelect(item);
                setOpen(false);
              }}
            >
              {item}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default DropdownButton;

const dropdownStyle: React.CSSProperties = {
  position: 'absolute',
  top: '100%',
  left: 0,
  margin: 0,
  padding: '4px 0',
  background: 'white',
  border: '1px solid #ccc',
  borderRadius: '4px',
  listStyle: 'none',
  boxShadow: '0 2px 6px rgba(0,0,0,0.15)',
  zIndex: 100,
};

const liStyle: React.CSSProperties = {
  padding: '6px 12px',
  cursor: 'pointer',
  whiteSpace: 'nowrap',
  fontSize: '14px',
  userSelect: 'none',
};
