'use client';

import React from 'react';
import { useSlate } from 'slate-react';
import { Editor, Range, Transforms, Element as SlateElement } from 'slate';

import MarkButton from './MarkButton';
import DropdownButton from './DropdownButton';
import InfoBoxDropdown from './InfoBoxDropdown';

import { insertLink, insertLinkBlock, unwrapLink, isLinkActive } from './helpers/insertLink';
import { insertHeading } from './helpers/insertHeading';
import { insertDivider } from './helpers/insertDivider';
import { toggleMark } from './helpers/toggleMark';

type ToolbarProps = {
  selectionRef: React.RefObject<Range | null>;
};

export const Toolbar: React.FC<ToolbarProps> = ({ selectionRef }) => {
  const editor = useSlate();

  const COLORS = ['black', 'red', 'blue', 'green', 'orange'];
  const FONT_SIZES = ['11px', '15px', '19px', '24px', '30px'];
  const BACKGROUND_COLORS = ['yellow', 'lightgreen', 'lightblue', 'lightpink', 'lightgray'];
  const HEADINGS = [
    { label: '제목 1 추가', value: 'heading-one' },
    { label: '제목 2 추가', value: 'heading-two' },
    { label: '제목 3 추가', value: 'heading-three' },
  ];
  const ALIGNMENTS = [
    { label: '왼쪽 정렬', value: 'left' },
    { label: '가운데 정렬', value: 'center' },
    { label: '오른쪽 정렬', value: 'right' },
    { label: '양쪽 정렬', value: 'justify' },
  ];

  const handleInsertLink = () => {
    const url = prompt('링크할 URL을 입력하세요');
    if (!url) return;

    if (isLinkActive(editor)) unwrapLink(editor);

    const isCollapsed = Range.isCollapsed(editor.selection!);
    if (isCollapsed) insertLinkBlock(editor, url);
    else insertLink(editor, url);
  };

  const setAlignment = (alignment: 'left' | 'center' | 'right' | 'justify') => {
    Transforms.setNodes(
      editor,
      { textAlign: alignment },
      {
        match: (n): n is SlateElement => SlateElement.isElement(n) && Editor.isBlock(editor, n),
      }
    );
  };

  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '10px' }}>
      <MarkButton format="bold" label="B" />
      <MarkButton format="italic" label="I" />
      <MarkButton format="underline" label="U" />
      <MarkButton format="strikethrough" label="S" />

      <DropdownButton label="색상" items={COLORS} onSelect={(value) => toggleMark(editor, 'color', value)} />
      <DropdownButton label="폰트" items={FONT_SIZES} onSelect={(value) => toggleMark(editor, 'fontSize', value)} />
      <DropdownButton label="배경색" items={BACKGROUND_COLORS} onSelect={(value) => toggleMark(editor, 'backgroundColor', value)} />

      <button onMouseDown={(e) => { e.preventDefault(); handleInsertLink(); }}>🔗 링크 삽입</button>

      <DropdownButton
        label="제목 추가"
        items={HEADINGS.map(h => h.label)}
        onSelect={(label) => {
          const match = HEADINGS.find(h => h.label === label);
          if (match) insertHeading(editor, match.value as any);
        }}
      />

      <DropdownButton
        label="정렬"
        items={ALIGNMENTS.map(a => a.label)}
        onSelect={(label) => {
          const match = ALIGNMENTS.find(a => a.label === label);
          if (match) setAlignment(match.value as any);
        }}
      />

      <button onMouseDown={(e) => { e.preventDefault(); insertDivider(editor); }}>─ 구분선 삽입</button>
      <InfoBoxDropdown selectionRef={selectionRef} />
    </div>
  );
};
