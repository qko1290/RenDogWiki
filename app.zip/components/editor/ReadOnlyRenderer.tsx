'use client';

import { Descendant } from 'slate';
import { Slate, Editable, withReact } from 'slate-react';
import { useMemo } from 'react';
import { createEditor } from 'slate';

import Element from './Element';
import Leaf from './Leaf';

export default function ReadOnlyRenderer({ value }: { value: Descendant[] }) {
  const editor = useMemo(() => withReact(createEditor()), []);

  return (
    <Slate editor={editor} initialValue={value} onChange={() => {}}>
      <Editable
        readOnly
        renderElement={(props) => <Element {...props} editor={editor} onIconClick={() => {}} />}
        renderLeaf={(props) => <Leaf {...props} />}
        style={{ padding: '16px' }}
      />
    </Slate>
  );
}
