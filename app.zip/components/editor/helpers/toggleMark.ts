import { Editor, Transforms, Text } from 'slate';
import type { MarkFormat } from '@/types/slate';

export const isMarkActive = (editor: Editor, format: MarkFormat) => {
  const marks = Editor.marks(editor);
  return marks ? marks[format] !== undefined : false;
};

export const toggleMark = (
  editor: Editor,
  format: MarkFormat | 'color' | 'fontSize' | 'backgroundColor',
  value?: string
) => {
  const isActive = isMarkActive(editor, format as MarkFormat);

  if (format === 'color' || format === 'fontSize' || format === 'backgroundColor') {
    Transforms.setNodes(
      editor,
      { [format]: value },
      { match: Text.isText, split: true }
    );
  } else {
    if (isActive) {
      Editor.removeMark(editor, format);
    } else {
      Editor.addMark(editor, format, true);
    }
  }
};
