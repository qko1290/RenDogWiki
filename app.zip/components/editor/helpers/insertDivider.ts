import { Editor, Transforms } from 'slate';
import type { DividerElement, ParagraphElement } from '@/types/slate';

export const insertDivider = (editor: Editor) => {
  const divider: DividerElement = {
    type: 'divider',
    children: [{ text: '' }],
  };

  const paragraph: ParagraphElement = {
    type: 'paragraph',
    children: [{ text: '' }],
  };

  Transforms.insertNodes(editor, [divider, paragraph]);
};
