import { Editor, Transforms, Range, Element as SlateElement } from 'slate';
import type { LinkElement, LinkBlockElement, ParagraphElement } from '@/types/slate';

// 인라인 링크 삽입
export const insertLink = (editor: Editor, url: string) => {
  if (!editor.selection) return;
  const isCollapsed = Range.isCollapsed(editor.selection);

  const link: LinkElement = {
    type: 'link',
    url,
    children: isCollapsed ? [{ text: url }] : [],
  };

  if (isCollapsed) {
    Transforms.insertNodes(editor, link);
  } else {
    Transforms.wrapNodes(editor, link, { split: true });
    Transforms.collapse(editor, { edge: 'end' });
  }
};

// 링크 블럭 삽입
export const insertLinkBlock = (editor: Editor, url: string) => {
  const hostname = new URL(url).hostname.replace('www.', '');
  const favicon = `https://www.google.com/s2/favicons?sz=64&domain_url=${url}`;

  const linkBlock: LinkBlockElement = {
    type: 'link-block',
    url,
    size: 'large',
    favicon,
    sitename: hostname,
    children: [{ text: '' }],
  };

  const paragraph: ParagraphElement = {
    type: 'paragraph',
    children: [{ text: '' }],
  };

  Transforms.insertNodes(editor, paragraph);
};

export const unwrapLink = (editor: Editor) => {
  Transforms.unwrapNodes(editor, {
    match: n => SlateElement.isElement(n) && n.type === 'link',
  });
};

export const isLinkActive = (editor: Editor) => {
  const [match] = Editor.nodes(editor, {
    match: n => SlateElement.isElement(n) && n.type === 'link',
  });
  return !!match;
};
