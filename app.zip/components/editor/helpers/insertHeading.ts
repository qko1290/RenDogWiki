import { Editor, Transforms } from 'slate';
import type { ParagraphElement, CustomElement, HeadingElement  } from '@/types/slate';

export const insertHeading = (
  editor: Editor,
  heading: 'heading-one' | 'heading-two' | 'heading-three'
) => {
  if (!editor.selection) return;

  const icon = prompt('제목 앞에 표시할 이모지 또는 이미지 URL을 입력하세요') || '';

  Transforms.setNodes(
    editor,
    { type: heading, icon } as Partial<HeadingElement>
  );

  const paragraph: ParagraphElement = {
    type: 'paragraph',
    children: [{ text: '' }],
  };

  const nextPoint = Editor.after(editor, editor.selection.focus.path);
  if (nextPoint) {
    Transforms.insertNodes(editor, paragraph, { at: nextPoint });
    Transforms.select(editor, nextPoint);
  }
};
