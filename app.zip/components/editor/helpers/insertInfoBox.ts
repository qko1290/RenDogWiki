import { Transforms } from 'slate';
import type { Editor } from 'slate';
import type { InfoBoxType } from '@/types/slate';

const insertInfoBox = (editor: Editor, boxType: InfoBoxType) => {
  Transforms.insertNodes(editor, {
    type: 'info-box',
    boxType,
    children: [{ text: '' }],
  });
};

export default insertInfoBox;
