import { Descendant, Element as SlateElement, Text } from 'slate';

const headingIcons = {
  'heading-one': '📌',
  'heading-two': '🔖',
  'heading-three': '📝',
} as const;

export const extractHeadings = (value: Descendant[]) => {
  const headings: { text: string; id: string; level: 1 | 2 | 3; icon: string }[] = [];
  const slugMap = new Map<string, number>();

  const walk = (nodes: Descendant[]) => {
    for (const node of nodes) {
      if (!SlateElement.isElement(node)) continue;

      if (
        node.type === 'heading-one' ||
        node.type === 'heading-two' ||
        node.type === 'heading-three'
      ) {
        const textOnly = (node.children ?? [])
          .filter(child => Text.isText(child))
          .map(child => child.text)
          .join('')
          .trim();

        const cleanText = textOnly.replace(/^[^\w\s]|[\u{1F300}-\u{1F6FF}]/gu, '').trim();
        const baseSlug = cleanText.toLowerCase().replace(/\s+/g, '-');

        const count = slugMap.get(baseSlug) || 0;
        slugMap.set(baseSlug, count + 1);

        const uniqueSlug =
          count > 0
            ? `${baseSlug}-${count}`
            : baseSlug || `untitled-${Math.random().toString(36).slice(2, 6)}`;

        const level = node.type === 'heading-one' ? 1 : node.type === 'heading-two' ? 2 : 3;
        const icon = (node as any).icon || headingIcons[node.type];

        headings.push({ text: textOnly, id: `heading-${uniqueSlug}`, level, icon });
      }

      if (node.children) {
        walk(node.children as Descendant[]);
      }
    }
  };

  walk(value);
  return headings;
};
