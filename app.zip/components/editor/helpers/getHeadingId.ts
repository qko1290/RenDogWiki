import { Element as SlateElement, Node } from 'slate';

export const getHeadingId = (element: SlateElement) => {
  const raw = Node.string(
    element || { type: 'paragraph', children: [{ text: '' }] } as any
  ).trim();

  const cleaned = raw.replace(/^[^\w\s]|[\u{1F300}-\u{1F6FF}]/gu, '').trim();
  const slug = cleaned.toLowerCase().replace(/\s+/g, '-') || `untitled-${Math.random().toString(36).slice(2, 6)}`;

  return `heading-${slug}`;
};
