'use client';

import React, { useMemo, useState, useCallback, useEffect, useRef } from 'react';
import {
  createEditor, Descendant, Editor, Transforms, Range, Point, Element as SlateElement, Node
} from 'slate';
import { Slate, Editable, withReact, ReactEditor, RenderLeafProps, RenderElementProps } from 'slate-react';
import { withHistory } from 'slate-history';
import isHotkey from 'is-hotkey';

import { Toolbar } from './Toolbar';
import Leaf from './Leaf';
import Element from './Element';
import TableOfContents from './TableOfContents';
import { extractHeadings } from './helpers/extractHeadings';
import type { CustomElement } from '@/types/slate';

export default function SlateEditor() {
  const editor = useMemo(() => {
    const e = withHistory(withReact(createEditor()));
    const originalIsVoid = e.isVoid;
    e.isVoid = element =>
      element.type === 'link-block' || element.type === 'divider' ? true : originalIsVoid(element);
    return e;
  }, []);

  const selectionRef = useRef<Range | null>(null);

  const [value, setValue] = useState<Descendant[]>([{
    type: 'paragraph',
    children: [{ text: '' }]
  }]);

  const [isIconModalOpen, setIsIconModalOpen] = useState(false);
  const [iconEditTarget, setIconEditTarget] = useState<CustomElement | null>(null);

  useEffect(() => {
    const preventBackspaceNavigation = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const isEditable =
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.isContentEditable;
      if (e.key === 'Backspace' && !isEditable) {
        e.preventDefault();
      }
    };
    window.addEventListener('keydown', preventBackspaceNavigation);
    return () => window.removeEventListener('keydown', preventBackspaceNavigation);
  }, []);

  const headings = useMemo(() => extractHeadings(value), [value]);

  const handleIconClick = (element: CustomElement) => {
    setIconEditTarget(element);
    setIsIconModalOpen(true);
  };

  const renderLeaf = useCallback((props: RenderLeafProps) => <Leaf {...props} />, []);
  const renderElement = useCallback(
    (props: RenderElementProps) => (
      <Element {...props} editor={editor} onIconClick={handleIconClick} />
    ),
    [editor]
  );

  const handleSave = async () => {
    const res = await fetch('/api/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        path: '무기/활/롱보우', // 나중에 입력값으로 대체 가능
        content: value,
      }),
    });

    if (res.ok) {
      alert('저장 완료!');
    } else {
      alert('저장 실패');
    }
  };

  const onKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    const HOTKEYS: Record<string, string> = {
      'mod+b': 'bold',
      'mod+i': 'italic',
      'mod+u': 'underline',
      'mod+shift+x': 'strikethrough',
    };

    for (const hotkey in HOTKEYS) {
      if (isHotkey(hotkey, event)) {
        event.preventDefault();
        const format = HOTKEYS[hotkey];
        Transforms.setNodes(
          editor,
          { [format]: true },
          {
            match: n => SlateElement.isElement(n) && Editor.isInline(editor, n),
          }
        );
      }
    }

    if (event.key === 'Backspace') {
      const { selection } = editor;
      if (selection && Range.isCollapsed(selection)) {
        const [match] = Editor.nodes(editor, {
          match: n =>
            SlateElement.isElement(n) &&
            ['heading-one', 'heading-two', 'heading-three'].includes(n.type),
        });
        if (match) {
          const [, path] = match;
          const start = Editor.start(editor, path);
          if (Point.equals(selection.anchor, start)) {
            event.preventDefault();
            Transforms.removeNodes(editor, { at: path });
            Transforms.insertNodes(editor, {
              type: 'paragraph',
              children: [{ text: '' }],
            });
            const point = Editor.start(editor, [0]);
            Transforms.select(editor, point);
          }
        }
      }
    }

    if (event.key === 'Enter') {
      const [match] = Editor.nodes(editor, {
        match: n =>
          SlateElement.isElement(n) &&
          ['heading-one', 'heading-two', 'heading-three'].includes(n.type),
      });
      if (match) {
        event.preventDefault();
        Transforms.insertNodes(editor, {
          type: 'paragraph',
          children: [{ text: '' }],
        });
      }
    }
  };

  return (
    <div style={{ display: 'flex' }}>
      <div style={{ flex: 1 }}>
        <Slate editor={editor} initialValue={value} onChange={setValue}>
          <Toolbar selectionRef={selectionRef} />
          <button
            onClick={handleSave}
            style={{ margin: '8px 0', padding: '6px 12px', borderRadius: '4px', background: '#0070f3', color: 'white', border: 'none' }}
          >
            저장하기
          </button>
          <Editable
            renderLeaf={renderLeaf}
            renderElement={renderElement}
            onKeyDown={onKeyDown}
            placeholder="문서를 작성하세요..."
            spellCheck={false}
            style={{
              border: '1px solid #ccc',
              padding: '12px',
              borderRadius: '6px',
              minHeight: '300px',
            }}
            onBlur={() => {
              selectionRef.current = editor.selection;
            }}
          />
        </Slate>
      </div>
      <TableOfContents headings={headings} />
      {isIconModalOpen && iconEditTarget && (
        <div style={{
          position: 'fixed',
          top: '30%',
          left: '40%',
          background: 'white',
          padding: '20px',
          border: '1px solid #ccc',
          borderRadius: '8px',
          zIndex: 1000,
          boxShadow: '0 0 10px rgba(0,0,0,0.2)'
        }}>
          <h4>아이콘 수정</h4>
          <input
            type="text"
            placeholder="이모지 또는 이미지 URL 입력"
            autoFocus
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                const newIcon = (e.target as HTMLInputElement).value;
                if (iconEditTarget && SlateElement.isElement(iconEditTarget)) {
                  const path = ReactEditor.findPath(editor, iconEditTarget);
                  Transforms.setNodes(editor, { icon: newIcon }, { at: path });
                }
                setIsIconModalOpen(false);
                setIconEditTarget(null);
              }
            }}
            style={{ width: '100%', marginBottom: '10px' }}
          />
          <div>
            <button onClick={() => {
              setIsIconModalOpen(false);
              setIconEditTarget(null);
            }}>취소</button>
          </div>
        </div>
      )}
    </div>
  );
}