'use client';

import React from 'react';
import { RenderLeafProps } from 'slate-react';

const Leaf = ({ attributes, children, leaf }: RenderLeafProps) => {
  const style: React.CSSProperties = {};

  if (leaf.color) style.color = leaf.color;
  if (leaf.fontSize) style.fontSize = leaf.fontSize;
  if (leaf.backgroundColor) style.backgroundColor = leaf.backgroundColor;
  if (leaf.bold) children = <strong>{children}</strong>;
  if (leaf.italic) children = <em>{children}</em>;
  if (leaf.underline) children = <u>{children}</u>;
  if (leaf.strikethrough) children = <s>{children}</s>;

  return (
    <span {...attributes} style={style}>
      {children}
    </span>
  );
};

export default Leaf;
