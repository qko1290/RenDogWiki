import { NextRequest, NextResponse } from 'next/server';
import path from 'path';
import { writeFile, mkdir } from 'fs/promises';

export async function POST(req: NextRequest) {
  const { path: docPath, content } = await req.json();

  const baseDir = path.join(process.cwd(), 'public/docs');
  const targetPath = path.join(baseDir, ...docPath.split('/')) + '.json';
  const folder = path.dirname(targetPath);

  await mkdir(folder, { recursive: true });
  await writeFile(targetPath, JSON.stringify({ content }, null, 2), 'utf-8');

  return NextResponse.json({ success: true });
}
