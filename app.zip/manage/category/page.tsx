export default function ManageCategoryPage() {
    return (
      <main>
        <h1>렌독 위키 - 카테고리 관리</h1>
      </main>
    );
  }
  