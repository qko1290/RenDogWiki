'use client';
import SlateEditor from '../../components/editor/SlateEditor';

export default function WritePage() {
  return <SlateEditor />;
}