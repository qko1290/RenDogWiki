'use client';

import './css/wiki.css';
import { useState, useEffect } from 'react';
import { renderSlateToHtml } from './lib/renderSlateToHtml';

type CategoryNode = {
  name: string;
  order?: number;
  children?: CategoryNode[];
};

export default function WikiPage() {
  const [categories, setCategories] = useState<CategoryNode[]>([]);
  const [openPaths, setOpenPaths] = useState<string[][]>([]);
  const [selectedDocPath, setSelectedDocPath] = useState<string[] | null>(null);
  const [docContent, setDocContent] = useState<string>('');

  useEffect(() => {
    fetch('/categories/categories.json')
      .then((res) => res.json())
      .then((data) => setCategories(data))
      .catch((err) => console.error('카테고리 로딩 실패:', err));
  }, []);

  const togglePath = (path: string[]) => {
    setOpenPaths(prev =>
      prev.some(p => JSON.stringify(p) === JSON.stringify(path))
        ? prev.filter(p => JSON.stringify(p) !== JSON.stringify(path))
        : [...prev, path]
    );
  };

  const isPathOpen = (path: string[]) =>
    openPaths.some(p => JSON.stringify(p) === JSON.stringify(path));

  const isLeaf = (node: CategoryNode) => !node.children || node.children.length === 0;

  const fetchDoc = (path: string[]) => {
    setSelectedDocPath(path);
    const filePath = `/docs/${path.join('/')}.json`;

    fetch(filePath)
      .then((res) => {
        if (!res.ok) throw new Error('문서를 찾을 수 없습니다.');
        return res.json();
      })
      .then((data) => {
        const html = renderSlateToHtml(data.content);
        setDocContent(html);
      })
      .catch((err) => {
        console.error(err);
        setDocContent('<p>문서를 찾을 수 없습니다.</p>');
      });
  };

  const renderTree = (nodes: CategoryNode[], parentPath: string[] = []) => (
    <ul className={parentPath.length > 0 ? 'wiki-sub-nav-list' : 'wiki-nav-list'}>
      {nodes.map((node) => {
        const currentPath = [...parentPath, node.name];
        const isOpen = isPathOpen(currentPath);
        const isActive = selectedDocPath && JSON.stringify(selectedDocPath) === JSON.stringify(currentPath);

        return (
          <li key={node.name}>
            <button
              className={
                parentPath.length > 0
                  ? `wiki-sub-nav-item ${isActive ? 'active' : ''}`
                  : `wiki-nav-item ${isOpen ? 'active' : ''}`
              }
              onClick={() => {
                if (isLeaf(node)) {
                  fetchDoc(currentPath);
                } else {
                  togglePath(currentPath);
                }
              }}
            >
              {node.name}
              {!isLeaf(node) && (
                <span className="wiki-arrow">{isOpen ? '▼' : '▶'}</span>
              )}
            </button>
            {!isLeaf(node) && isOpen && renderTree(node.children!, currentPath)}
          </li>
        );
      })}
    </ul>
  );

  return (
    <div className="wiki-container">
      <header className="wiki-header">
        <h1 className="wiki-logo">RDWIKI</h1>
        <div className="wiki-search-container">
          <input
            type="text"
            className="wiki-search"
            placeholder="검색어를 입력하세요..."
          />
        </div>
      </header>

      <div className="wiki-main">
        <aside className="wiki-sidebar">
          <h2 className="wiki-sidebar-title">카테고리</h2>
          {renderTree(categories)}
        </aside>

        <main className="wiki-content">
          <div className="wiki-breadcrumb">
            {selectedDocPath ? (
              <div className="wiki-breadcrumb-flex">
                <button
                  className="wiki-back-button"
                  onClick={() => {
                    setSelectedDocPath(null);
                    setDocContent('');
                  }}
                >
                  ←
                </button>
                <span>{selectedDocPath.join(' > ')}</span>
              </div>
            ) : (
              <span>렌독 위키 - 문서 목록</span>
            )}
          </div>

          <h2 className="wiki-content-title">
            {selectedDocPath?.at(-1) || '렌독 위키'}
          </h2>

          <div
            className="wiki-content-body"
            dangerouslySetInnerHTML={{ __html: docContent || '오른쪽 본문 영역입니다.' }}
          />
        </main>
      </div>
    </div>
  );
}
