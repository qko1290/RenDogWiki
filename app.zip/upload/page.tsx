export default function UploadPage() {
    return (
      <main>
        <h1>렌독 위키 - 문서 업로드</h1>
      </main>
    );
  }
  